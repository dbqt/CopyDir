CopyDir : MS-DOS Script by David Binh Quang Tran
Copyleft 2015


To use the CopyDir.bat

1-You have to open it in a text editor (notepad is fine).
2-Change the line 
	set dest="K:\Dossier User\Desktop\ttttt"
  and set a new path to where you want to copy everything into.
3-Save the file.
4-Place the CopyDir.bat file into the root of what you want to copy.
5-Double-click/Run the CopyDir.bat file.
6-Follow the instruction on the console screen.
7-That's it!